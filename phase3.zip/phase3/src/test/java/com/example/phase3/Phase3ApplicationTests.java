package com.example.phase3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import com.example.phase3.bean.Loanbeans;
import com.example.phase3.exception.LoanApplyException;
import com.example.phase3.exception.LoginException;
import com.example.phase3.exception.NoEnoghBalanceException;
import com.example.phase3.exception.NoPendingLoansException;
import com.example.phase3.service.LoanServiceImpl;
  
@SpringBootTest
@Transactional
@Rollback(true)
class Phase3ApplicationTests {

	@Autowired
	LoanServiceImpl service;
	
	Loanbeans account = new Loanbeans("Sowjanya","Reddy",45,800000.0,90000.0,"BMRPT9635G","7418523690","sowjanya@gmail.com","sowg1234","sowg1234",850000.0,8);
	Loanbeans acc=new Loanbeans("Sowjanya","Reddy",45,800000.0,90000.0,"BMRPT9635G","7418523690","sowjanya@gmail.com","sowg1235","sowg1235",50000.0,8);
	Loanbeans acc1=new Loanbeans("Sowjanya","Reddy",45,800000.0,90000.0,"BMRPT9635G","7418523690","sowjanya@gmail.com","sowg1234","sowg1234",80000.0,8);

	@Test
	public void test1() throws LoginException 
	{
		int balance = service.validate("maha1235", "maha1235");
		assertEquals(1, balance);	
	}
	
	@Test
	public void test2()
	{
		assertThrows(LoginException.class, ()->{ service.validate("maha1239", "maha1235"); });
	}
	
	
	@Test
	public void test3() 
	{
		double balance = service.balanceDetails("maha1235");
		assertEquals(9997, balance,1);	
	}
	
	
	
	@Test
	public void test4()
	{
		double amount = service.depositAmount("many1235",50000);
		assertEquals(50000, amount,1);		
	}
	
	
	
	
	@Test
	public void test5() throws LoanApplyException
	{
		int loan = service.createAccount(account);
		assertEquals(5001016,loan,1);
		}
	
	@Test
	public void test6()
	{
		assertThrows(LoanApplyException.class, ()->{ service.createAccount(acc);});
	}
	
	@Test
	public void test7()
	{
		assertThrows(LoanApplyException.class, ()->{ service.createAccount(acc1);});
		}
	
		
	@Test
	public void test8()
	{
		assertThrows(NoEnoghBalanceException.class, ()->{ service.payEmi("maha1235");});
	}
	
	@Test
	public void test9()
	{
		assertThrows(NoPendingLoansException.class, ()->{service.payEmi("many1235");});
	}
	

	
	  @Test public void test10() throws NoPendingLoansException, NoEnoghBalanceException 
	  {
	    int payEmi = service.payEmi("srin1233");
	  	assertEquals(1,payEmi,1); 
	 }
	 
	
	
	@Test
	public void test11()
	{
		assertThrows(NoPendingLoansException.class, ()->{ service.foreclose("many1235");});
	}
	
	@Test
	public void test12()
	{
		assertThrows(NoEnoghBalanceException.class, ()->{ service.foreclose("maha1235");});
	}
	
  @Test
  public void test13()
  {
	  double emi=service.calEmi(5001014);
	  assertEquals(0,emi,1);
  }
  @Test
  public void test14() throws NoEnoghBalanceException, NoPendingLoansException
  
  {
	    int foreclose = service.foreclose("mkrr1233");
	  	assertEquals(1,foreclose,1); 
	 }
}



