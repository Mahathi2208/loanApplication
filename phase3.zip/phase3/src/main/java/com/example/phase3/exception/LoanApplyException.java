package com.example.phase3.exception;

public class LoanApplyException extends Exception{
	public LoanApplyException() {
		
	}
	public LoanApplyException(String message) {
		super(message);
	}
public LoanApplyException(String message,Throwable t)
{
	super(message,t);
}
}
