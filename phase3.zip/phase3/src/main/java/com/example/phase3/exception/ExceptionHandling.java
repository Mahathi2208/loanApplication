package com.example.phase3.exception;

import java.nio.file.attribute.UserPrincipalNotFoundException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

public class ExceptionHandling extends ResponseEntityExceptionHandler {
	
	
	
	
	@ExceptionHandler(LoginException.class)
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleLoginExcption(final LoginException exception,final HttpServletRequest request) {
ExceptionResponse error=new ExceptionResponse(exception.getLocalizedMessage());
	return error;
}
	
	@ExceptionHandler(IncorrectPasswordException.class)
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleIncorrectPasswordException(final IncorrectPasswordException exception,final HttpServletRequest request) {
ExceptionResponse error=new ExceptionResponse(exception.getLocalizedMessage());
	return error;
}
	
	@ExceptionHandler(LoanApplyException.class)
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleLoanApplyException(final LoanApplyException exception,final HttpServletRequest request) {
ExceptionResponse error=new ExceptionResponse(exception.getLocalizedMessage());
	return error;
}	

	
	@ExceptionHandler(NoEnoghBalanceException.class)
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleNoEnoughBalanceException(final NoEnoghBalanceException exception,final HttpServletRequest request) {
ExceptionResponse error=new ExceptionResponse(exception.getLocalizedMessage());
	return error;
}
	
	@ExceptionHandler(NoPendingLoansException.class)
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleNoPendingLoansException(final NoPendingLoansException exception,final HttpServletRequest request) {
ExceptionResponse error=new ExceptionResponse(exception.getLocalizedMessage());
	return error;
}
	
}
