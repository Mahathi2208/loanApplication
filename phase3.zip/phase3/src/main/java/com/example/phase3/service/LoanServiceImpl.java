package com.example.phase3.service;



import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.phase3.Hello;
import com.example.phase3.bean.Loanbeans;
import com.example.phase3.bean.Transaction;


import com.example.phase3.dao.LoanDaoImpl;

import com.example.phase3.exception.LoanApplyException;
import com.example.phase3.exception.LoginException;
import com.example.phase3.exception.NoEnoghBalanceException;
import com.example.phase3.exception.NoPendingLoansException;




@Service
public class LoanServiceImpl implements LoanService{
	@Autowired
 LoanDaoImpl dao;
  
	Logger logger=LoggerFactory.getLogger(LoanServiceImpl.class);	
	
/*Method: payEmi
 * Description:Used to pay EMI for loan issued to the user .
 * @param username :Username of the user
 * @return int:it returns an integer on a successful payment of EMI
 * @throws NoPendingLoansException :it is raised when the user does not have any pending loans
 * @throws NoEnoughBalanceException:it is raised when the user does not have enough balance to pay the EMI
 */
		@Override
		@Transactional
		public int payEmi(String username) throws NoPendingLoansException,NoEnoghBalanceException{
			Loanbeans lb=dao.findAccount(username);
			double pendingLoan,remainingBalance;
			
				
				if(lb.getLoanAmount()==0.0)
				{
					logger.error("no pending loans....");
					throw new NoPendingLoansException("No pending Loans");
				}
				if(lb.getBalance()>lb.getEmi()) {
					 pendingLoan=lb.getLoanAmount()-lb.getEmi();
					 remainingBalance=lb.getBalance()-lb.getEmi();
					 	lb.setBalance(remainingBalance);
						lb.setLoanAmount(pendingLoan);
						Transaction tr =new Transaction();
						tr.setAccountNumber(lb.getAccountNumber());
						tr.setCurrentBalance(lb.getBalance());
						tr.setTransactionId(lb.getTransactionCount()+1);
						lb.setTransactionCount(lb.getTransactionCount()+1);
						tr.setTransactionType(lb.getEmi()+" Debited");
						
						dao.printAccount(tr);
					logger.info("emi payment completed....");
					return 1;
					}
					else
					{
						logger.error("no enough balance....");
						throw new NoEnoghBalanceException("No enough balance to pay emi");
					}
				
					
		}
		
		
		
		
/*Method:createAccount
 * Description:used to create an account of user for loan application
 * @param l:it is of type Loanbeans which is the data entered by the user to apply loan
 * @return int:it returns an integer of account number once the account gets created
 * @throws LoanApplyException:it is raised when the username already exists or when the asset value is less than that of loan amount
 */
		@Override
		@Transactional
		public int createAccount(Loanbeans l) throws LoanApplyException
		{
			if(l.getAssetValue()>l.getLoanAmount()) {
			int accountNumberGenerated=dao.accountNumberGeneration(l);
			if(accountNumberGenerated!=0) {
			l.setAccountNumber(accountNumberGenerated);
			dao.createAccount(l);
			calEmi(accountNumberGenerated);
			logger.info("loan application successful...");
			 return accountNumberGenerated;
		}
			else {
				logger.error("username already exists....");
				throw new LoanApplyException("Username already exists");
			}
		}
			else {
				logger.error("asset value is not greater than the loan amount...");
				throw new LoanApplyException("Asset value must be greater than loan amount");
			}
		}

		
		
/*Method:findAccount
 * Description:used to get all details of the user based on the username
 * @param username:Username of the user
 * @return Loanbeans:it return the user account details of type Loanbeans once found
 */
		@Override
		@Transactional
		public Loanbeans findAccount(String username)
		{
			logger.info("account found successfully....");
			return dao.findAccount(username);  
		}
		

/*Method:balanceDetails
 * Description:used to get the balance details of the user
 * @param username:Username of the user
 * @return double:it returns the balance in the user account
 */
		@Override
		@Transactional
		public double balanceDetails(String username)
		{
			logger.info("returning balance details..");
			return dao.balanceDetails(username) ;
		}
		
		
/*Method:validate
 * Description:used to validate the login credentials like username and password of the user
 * @param username:Username of the user
 * @param password:Password of the user
 * @return int:it returns an integer if the validation is successfull
 * @throws LoginException:it is raised when the username is not found or the username and password does not match
 */
		@Override
		@Transactional
		public int validate(String username,String password) throws LoginException
		{
					
			 int checkingLogin= dao.validate(username,password);
				if(checkingLogin==0) {
					logger.error("password validation failed...");
					throw new LoginException("Invalid Login Credentials");
					}
				logger.info("password validation successful...");
			 return checkingLogin;
		}
		

/*Method: foreclose
* Description:Used to pay EMI for loan issued to the user .
* @param username :Username of the user
* @return int:it returns an integer on a successful foreclose of loan
* @throws NoPendingLoansException :it is raised when the user does not have any pending loans
* @throws NoEnoughBalanceException:it is raised when the user does not have enough balance to pay the EMI
*/		
		@Override
		@Transactional
		public int foreclose(String username) throws NoEnoghBalanceException,NoPendingLoansException{
			
			    Loanbeans lb=dao.findAccount(username);
				if(lb.getLoanAmount()==0.0) {
					logger.error("no pending loans....");
					throw new NoPendingLoansException("No pending Loans");
				}
				
				else if(lb.getLoanAmount()<lb.getBalance())
				{
					double remainingBalance=lb.getBalance()-lb.getLoanAmount();
					double foreclosedAmount=lb.getLoanAmount();
					lb.setBalance(remainingBalance);
					lb.setLoanAmount(0.0);
					lb.setEmi(0.0);
					Transaction tr =new Transaction();
					tr.setAccountNumber(lb.getAccountNumber());
					tr.setCurrentBalance(lb.getBalance());
					tr.setCurrentBalance(lb.getBalance());
					tr.setTransactionId(lb.getTransactionCount()+1);
					lb.setTransactionCount(lb.getTransactionCount()+1);
					tr.setTransactionType(foreclosedAmount+" Debited");
					
					dao.printAccount(tr);
					logger.info("foreclose successful....");
					return 1;
					
				}
				else {
					logger.error("no enough balance....");
					throw new NoEnoghBalanceException("No enough Balance to Foreclose");
				}
		}
		
		
		
/*Method:depositAmount
 * Description:used to deposit the amount into the users account
 * @param username:Username of the user
 * @param depositAmount
 * @return double:it returns the amount deposited once the transaction is completed
 */
		@Override
		@Transactional
		public double depositAmount(String username,double depositAmount) {
			Loanbeans lb=dao.findAccount(username);
			double currentBalanace=lb.getBalance();
			double updatedBalance=currentBalanace+depositAmount;
			lb.setBalance(updatedBalance);
			Transaction tr =new Transaction();
			tr.setAccountNumber(lb.getAccountNumber());
			tr.setTransactionId(lb.getTransactionCount()+1);
		    lb.setTransactionCount(lb.getTransactionCount()+1);
		    tr.setCurrentBalance(lb.getBalance());
		    tr.setTransactionType(depositAmount+" credited");
	
		dao.printAccount(tr); 
		    logger.info("amount deposition successful....");
			return depositAmount;
			
		}
		
		
		
/*Method:calEmi
 * Description:it is used to calculate EMI for user bassed on the loan amount and the years time taken
 * @param accountNumber:account number of the user 
 */
		@Override
		@Transactional
		public double calEmi(int accountNumber)
		{	
				Loanbeans lb=dao.getData(accountNumber);
				double takenLoanAmount=lb.getLoanAmount();
				int numberOfYears=lb.getYears();
				float rateOfInterest=(float) 1.2;
				double emi=((takenLoanAmount/numberOfYears)/12)*rateOfInterest;
				
				lb.setEmi(Math.round(emi));
				
				double em=dao.emiCalculate(accountNumber,lb.getEmi());
			logger.info("EMI calculated");
			return em;
		}


		
/*Method:printTransactions
 * Description:it is used to print all the  transactions made by the user
 * @param id:Username of the user
 * @return List:it returns a list  of all the transaction
 */
		@Override
		@Transactional
		public List<Transaction> printTransactions(String id) {
			Loanbeans lb=dao.findAccount(id);
			int acc=lb.getAccountNumber();
			logger.info("print transactions");
			return dao.printTransactions(acc);
		}
	
		}

