package com.example.phase3.exception;

public class NoEnoghBalanceException extends Exception{
public NoEnoghBalanceException()
{
	
}
public NoEnoghBalanceException(String message)
{
	super(message);
}
public NoEnoghBalanceException(String message,Throwable t)
{
	super(message,t);
}
}
