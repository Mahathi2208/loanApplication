package com.example.phase3.exception;

public class NoPendingLoansException extends Exception{
	public NoPendingLoansException()
	{
		
	}
	public NoPendingLoansException(String message)
	{
		super(message);
	}
	public NoPendingLoansException(String message,Throwable t) {
		super(message,t);
	}

}
