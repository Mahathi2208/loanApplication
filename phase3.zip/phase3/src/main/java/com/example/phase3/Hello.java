package com.example.phase3;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.phase3.bean.Loanbeans;
import com.example.phase3.bean.Transaction;

import com.example.phase3.exception.LoanApplyException;
import com.example.phase3.exception.LoginException;
import com.example.phase3.exception.NoEnoghBalanceException;
import com.example.phase3.exception.NoPendingLoansException;

import com.example.phase3.service.LoanService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class Hello {
private LoanService service;
@Autowired
public Hello(LoanService s)
{
	service=s;
}
Logger logger=LoggerFactory.getLogger(Hello.class);


/*To get a particular user details based 
on the username of the user*/
@GetMapping("/acc/{id}")
public Loanbeans getAccount(@PathVariable String id) 
{
	logger.info("find the user details....");
	return service.findAccount(id);
}

/*To validate the username and password in order to
login or payments like emi or foreclose*/
@GetMapping("/acc/pa/{id}/{password}")
public int validation(@PathVariable String id,@PathVariable String password) throws LoginException
{
	int w= service.validate(id,password);
    logger.info("validating username and password....");
	return w;
}


/*To get the balance details of the user 
based on the username*/
@GetMapping("/acc/bal/{id}")
public double getBalance(@PathVariable String id  )

{
	logger.info("fetching balance details.....");
	return service.balanceDetails(id);
}



/*When the user wants to deposit amount in their account
amount to deposit and username are to be given*/
@GetMapping("/acc/deposit/{id}/{amt}")
public double depositAmount(@PathVariable String id , @PathVariable double amt )
{
	logger.info("depositing money into users account...");
	return service.depositAmount(id, amt);
}


/*To pay the emi 
can throw an exception when there is no enough balance or
the user does not have any pending loans in the account*/
@GetMapping("/acc/pay/{id}")
public int emiPay(@PathVariable String id) throws NoEnoghBalanceException,NoPendingLoansException
{
	logger.info("processing emi payment.....");
	return service.payEmi(id);
}

/*To foreclose the loan
can throw an exception when there is no enough balance or
the user does not have any pending loans in the account*/
@GetMapping("/acc/foreclose/{id}")
public int foreclose(@PathVariable String id) throws NoEnoghBalanceException,NoPendingLoansException
{
	logger.info("processing foreclose.....");
	return service.foreclose(id);
}


/*
When a new loan application is made
can give exceptions like loanApplicationexception when the username already exists 
or the asset value is greater than loan amount*/
@PostMapping("/acc/add")//check again
public int createAccount(@RequestBody Loanbeans l) throws LoanApplyException
{
	logger.info("Applying for loan");
	return service.createAccount(l);
}




/*when user wants to print all his/her transactions made
like depositing money or payments ,this returns the transactions happened for that particular account */
@GetMapping("/acc/print/{id}")

public List<Transaction> printTransactions(@PathVariable String id)
{
	logger.info("printing transactions...");
	return service.printTransactions(id);
}
}
