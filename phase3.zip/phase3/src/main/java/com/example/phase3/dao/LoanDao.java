package com.example.phase3.dao;

import java.util.List;

import com.example.phase3.bean.Loanbeans;
import com.example.phase3.bean.Transaction;





public interface LoanDao {
	
	public Loanbeans findAccount(String username);
	public double balanceDetails(String username);
    public int validate(String username,String password);
	public void createAccount(Loanbeans l);
	public int accountNumberGeneration(Loanbeans l);
    public double emiCalculate(int accountNumber,double emi);
    public List<Transaction> printTransactions(int accountNumber);
	

}
