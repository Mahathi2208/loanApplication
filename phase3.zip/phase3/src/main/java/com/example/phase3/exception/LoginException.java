package com.example.phase3.exception;

public class LoginException extends Exception{
	public LoginException()
	{
		
	}
	public LoginException(String message)
	
	{
		super(message);
	}
	public LoginException(String message,Throwable t)
	{
		super(message,t);
	}
}
