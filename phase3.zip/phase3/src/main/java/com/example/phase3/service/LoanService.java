package com.example.phase3.service;

import java.util.List;

import com.example.phase3.bean.Loanbeans;
import com.example.phase3.bean.Transaction;

import com.example.phase3.exception.LoanApplyException;
import com.example.phase3.exception.LoginException;

import com.example.phase3.exception.NoEnoghBalanceException;
import com.example.phase3.exception.NoPendingLoansException;


public interface LoanService {

    public Loanbeans findAccount(String username);
	public double balanceDetails(String username);
    public int validate(String username,String password) throws LoginException;
	public int createAccount(Loanbeans l) throws LoanApplyException;
	public double depositAmount(String username,double depositAmount);
	public int payEmi(String username) throws NoPendingLoansException,NoEnoghBalanceException;
    public int foreclose(String username) throws NoEnoghBalanceException,NoPendingLoansException;
	public double calEmi(int accountNumber);
	public List<Transaction> printTransactions(String username);

}
