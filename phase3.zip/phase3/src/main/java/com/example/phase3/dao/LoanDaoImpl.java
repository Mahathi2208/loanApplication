package com.example.phase3.dao;

import java.util.List;
import java.util.Scanner;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import org.hibernate.Session;

import com.example.phase3.bean.Loanbeans;
import com.example.phase3.bean.Transaction;

@Repository
public class LoanDaoImpl implements LoanDao {
	
	@Autowired
	public EntityManager entityManager;


public LoanDaoImpl() {
		
	}


/*Method:getData
 * Discription:It is used to  obtainthe user details from database with the primary key account number
 * @param accountNumber:Account number of the user
 * @return Loanbeans:it returns the user data
 */
	public Loanbeans getData(int accountNumber) {
		Loanbeans bean = entityManager.find(Loanbeans.class, accountNumber);
		return bean;
	}
	
	
	
/*Method:findAccount
* Description:used to get all details of the user based on the username
* @param acc:Username of the user
* @return Loanbeans:it return the user account details of type Loanbeans once found
*/
	@Override
	@Transactional
	public Loanbeans findAccount(String acc)
	{
		String s = "" + acc;
		String Str = "SELECT accountNumber FROM Loanbeans where username=:num";
		TypedQuery<Integer> query1 = entityManager.createQuery(Str, Integer.class);
		query1.setParameter("num", s);
		int num = query1.getSingleResult();
		
		Loanbeans a = entityManager.find(Loanbeans.class, num);
		return a;
	}
	
	
	
/*Method:balanceDetails
* Description:used to get the balance details of the user
* @param acc:Username of the user
* @return double:it returns the balance in the user account
*/	
	@Override
	@Transactional
	public double balanceDetails(String acc) {
		Loanbeans bean = findAccount(acc);
		double bal=bean.getBalance();
		return bal;
	}

	
/*Method:validate
* Description:used to validate the login credentials like username and password of the user
* @param id:Username of the user
* @param password:Password of the user
* @return int:it returns an integer based on the validation status
*/
	@Override
	@Transactional
	public int validate(String id,String password)
	{
		String q1="SELECT b.username FROM Loanbeans b";
		TypedQuery<String> q2=entityManager.createQuery(q1,String.class);
		List<String> l1=q2.getResultList();
		if(l1.contains(id))
		{
			
			String s1 = "" + id;
			String qStr = "SELECT a.password FROM Loanbeans a  where a.username=:num";
			TypedQuery<String> query = entityManager.createQuery(qStr, String.class);
			query.setParameter("num", s1);
			String num1 = query.getSingleResult();
			if (num1.equals(password)) {
				return 1; 
			}
			else {
				return 0; 
			}
		}
		else
			return 0;
	}

	
/*Method:createAccount
* Description:used to create an account of user for loan application
* @param l:it is of type Loanbeans which is the data entered by the user to apply loan
*/
	@Override
	public void createAccount(Loanbeans l)
	{
		int acc=l.getAccountNumber();
		Transaction tr=new Transaction();
		tr.setAccountNumber(acc);
		tr.setTransactionType("Account Created");
		tr.setCurrentBalance(l.getBalance());
		System.out.println(tr.getCurrentBalance());
		tr.setTransactionId(1);
		entityManager.persist(l);
		entityManager.persist(tr);
		
	}
	
	
	
/*Method:printAccount
 * Discription:used to persist the transaction table
 * @param t:it is of type transaction
 */
	public void printAccount(Transaction t)
	{
		entityManager.persist(t);
	}

	
	
/*Method:emiCalculate
 * Discription:it is used to set the emi of the user account once calculated
 * @param accountNumber:Account number of the user
 * @param emi:EMI of the user
 * @return double:it the returns the monthly emi of the user
 */
	@Override
	public double emiCalculate(int accountNumber,double emi) {

		Loanbeans bean =getData(accountNumber);
		bean.setEmi(emi);
		return bean.getEmi();
	
	}
	

/*Method:accountNumberGeneration
 *Description:it is used to generated the account number for the user when applied for loan
 *@param l:it is of type loanbeans
 *@return int:it returns the account number 
 */
	@Override
	@Transactional
	public int accountNumberGeneration(Loanbeans l) {
		
	int startAcc=5001010;
		String qStr = "SELECT a.accountNumber FROM Loanbeans a";
		TypedQuery<Integer> query = entityManager.createQuery(qStr, Integer.class);
		
		List<Integer> usr = query.getResultList();
		String qStr1 = "SELECT username FROM Loanbeans";
		TypedQuery<String> query2 = entityManager.createQuery(qStr1, String.class);
		List<String> usr1 = query2.getResultList();
		if ( !usr1.contains(l.getUsername()) && !usr.isEmpty()) {
			String Str = "SELECT max(accountNumber) FROM Loanbeans";
			TypedQuery<Integer> query1 = entityManager.createQuery(Str, Integer.class);
			int num = query1.getSingleResult();
			return num+1; 
		} else if (usr.isEmpty()) {
			return startAcc; 
		} else {
			return 0; 
		}
	}


	
/*Method:printTransactions
* Description:it is used to print all the  transactions made by the user
* @param id:Username of the user
* @return List:it returns a list  of all the transaction
*/	
@Override
public List<Transaction> printTransactions(int accountNumber) {
	
	String str1 = "SELECT t from Transaction t where t.accountNumber=:no";
	TypedQuery<Transaction> q1= entityManager.createQuery(str1, Transaction.class);
	q1.setParameter("no", accountNumber);
	List<Transaction> t=q1.getResultList();
	return t;
	
}

}
