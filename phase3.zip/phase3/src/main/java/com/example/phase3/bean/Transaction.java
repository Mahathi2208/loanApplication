package com.example.phase3.bean;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Transaction")
public class Transaction {
	@Id
	@SequenceGenerator(name="myseq",sequenceName="sequence")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@Column(name="PRIMARYKEY")
	private int primaryKey;
	@Column(name="TRANSACTIONID")
	private int transactionId;
	@Column(name="ACCOUNTNUMBER")
    private int accountNumber;
	@Column(name="TRANSACTIONTYPE")
	private String transactionType;
	@Column(name="CURRENTBALANCE")
	private double currentBalance;
	public Transaction(int primaryKey ,int transactionId, int accountNumber, String transactionType,double currentBalance) {
		super();
		this.primaryKey=primaryKey;
		this.transactionId = transactionId;
		this.accountNumber = accountNumber;
		this.transactionType = transactionType;
		this.currentBalance=currentBalance;
	}
	public Transaction() {
		super();
	}
	public double getCurrentBalance() {
		return currentBalance;
	}
	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	@Override
	public String toString() {
		return "Transaction [primaryKey=" + primaryKey + ", transactionId=" + transactionId + ", accountNumber="
				+ accountNumber + ", transactionType=" + transactionType + "]";
	}

	
}