package com.example.phase3.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Loanbeans")
public class Loanbeans{
	
	@Id
	@Column(name="ACCOUNTNUMBER")
	private int accountNumber;
	@Column(name="FIRSTNAME")
    private String firstName;
	@Column(name="LASTNAME")
	private String lastName;
	@Column(name="AGE")
	private int age;
	@Column(name="LOANAMOUNT")
	private double loanAmount;
	@Column(name="BALANCE")
	private double balance;
	@Column(name="PANCARD")
	private String pancard;
	@Column(name="PHONENUMBER")
	private String phoneNumber;
	@Column(name="MAILID")
	private String mailId;
	@Column(name="USERNAME")
	private String username;
	@Column(name="PASSWORD")
	private String password;
	@Column(name="ASSETVALUE")
	private double assetValue;
	@Column(name="YEARS")
	private int years;
	@Column(name="EMI")
	private double emi;
	@Column(name="TRANSACTIONCOUNT")
	private int transactionCount;
	
	

	public Loanbeans() {
		
	}
	public Loanbeans(String firstName, String lastName, int age, double loanAmount, double balance,
			String pancard, String phoneNumber, String mailId, String username, String password, double assetValue,
			int years) {
	
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.loanAmount = loanAmount;
		this.balance = balance;
		this.pancard = pancard;
		this.phoneNumber = phoneNumber;
		this.mailId = mailId;
		this.username = username;
		this.password = password;
		this.assetValue = assetValue;
		this.years = years;

	}
	@Override
	public String toString() {
		return "LoanBean [accountNumber=" + accountNumber + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", age=" + age + ", loanAmount=" + loanAmount + ", balance=" + balance + ", pancard=" + pancard
				+ ", phoneNumber=" + phoneNumber + ", mailId=" + mailId + ", username=" + username + ", password="
				+ password + ", assetValue=" + assetValue + ", years=" + years + ", emi=" + emi + ", transactionCount="
				+ transactionCount + "]";
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getAssetValue() {
		return assetValue;
	}
	public void setAssetValue(double assetValue) {
		this.assetValue = assetValue;
	}
	public int getYears() {
		return years;
	}
	public void setYears(int years) {
		this.years = years;
	}
	public double getEmi() {
		return emi;
	}
	public void setEmi(double emi) {
		this.emi = emi;
	}
	public int getTransactionCount() {
		return transactionCount;
	}
	public void setTransactionCount(int transactionCount) {
		this.transactionCount = transactionCount;
	}
	
}
