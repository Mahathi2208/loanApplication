package com.example.phase3.exception;

public class IncorrectPasswordException extends Exception{
public IncorrectPasswordException()

{
	
}
public IncorrectPasswordException(String message)
{
	super(message);
}
public IncorrectPasswordException(String message,Throwable t)
{
	super(message,t);
}
}
