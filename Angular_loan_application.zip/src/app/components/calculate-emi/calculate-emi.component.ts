import { Component, OnInit } from '@angular/core';
import { Userservice1Service } from 'src/app/services/userservice1.service';
import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-calculate-emi',
  templateUrl: './calculate-emi.component.html',
  styleUrls: ['./calculate-emi.component.css']
})
export class CalculateEmiComponent implements OnInit {
  users:User;
  validate:number;
  constructor(private userService:Userservice1Service) { }

  u:string;
  ngOnInit() {
    let u=sessionStorage.username
this.userService.getDetails(u).subscribe(data=>{
  this.users=data;}
,
err=>{
  console.log(err.stack);
}
)
  }//end of ngOnInit function
  
}