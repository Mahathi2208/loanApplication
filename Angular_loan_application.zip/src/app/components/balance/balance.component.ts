import { Component, OnInit } from '@angular/core';
import { Userservice1Service } from 'src/app/services/userservice1.service';
import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.css']
})
export class BalanceComponent implements OnInit {
  users:User;
  validate:number;
  constructor(private userService:Userservice1Service) { }

  u:string;
  ngOnInit() {
    let u=sessionStorage.username
    //function to get details
this.userService.getDetails(u).subscribe(data=>{
  this.users=data;}
,
err=>{
  console.log(err.stack);
}
)
  }
  
}
