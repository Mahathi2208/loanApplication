import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Userservice1Service } from 'src/app/services/userservice1.service';
import { User } from 'src/app/models/user.model';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  users:User;
  validate:number;

// Router service to navigate programmatically from component to other

  constructor(private router:Router,private userService:Userservice1Service) { }

  ngOnInit() {
    if(sessionStorage.username==null)
    {
      this.router.navigate(['/login']);
    }
    let u=sessionStorage.username
    this.userService.getDetails(u).subscribe(data=>{
      this.users=data;}
    ,
    err=>{
      console.log(err.stack);
    }
    )
  }
  // logOut() function
logOut()
{
 
  if(sessionStorage.username != null){
   
    sessionStorage.removeItem("u");
  this.router.navigate(['login']);
}
}
//end of logout() funtion
}
