import { Component, OnInit, ɵɵpureFunction5 } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Userservice1Service } from 'src/app/services/userservice1.service';

@Component({
  selector: 'app-foreclose',
  templateUrl: './foreclose.component.html',
  styleUrls: ['./foreclose.component.css']
})
export class ForecloseComponent implements OnInit {
  //creating formGroup object
forecloseForm:FormGroup;
submitted:boolean=false;
validate1:number;
validate2:number;
validate:number;
// FormBuilder to build form elements with defaut values and validations
// Router service to navigate programmatically from component to other

constructor(private formBuilder:FormBuilder,private router:Router,private userservice:Userservice1Service) { }

  ngOnInit() {
    this.forecloseForm=this.formBuilder.group({
      password:['',Validators.required]
    });
  }
  //start of verify() function
  //validates password
  verify()
  {
    let u=sessionStorage.username;
      this.userservice.valid(u,this.forecloseForm.controls.password.value).subscribe(data=>{
        this.function5(data);
      },
      err=>{
        console.log(err.error);
        alert("Incorrect password");
      })

  }
  // end of verify() fumnction

  //function5() to process foreclose
  function5(data)
  {
    let u=sessionStorage.username;
    this.validate1=data;
  

this.userservice.forecloseAcc(u).subscribe(data=>{
  this.function6(data);
},
err=>{

  console.log(err.error)
  //error when no pending loans are present
  if(err.error.message=="No pending Loans"){
    alert("No pending Loans");
  }
   //error when no enough balance is present
  if(err.error.message=="No enough Balance to Foreclose"){
    alert("No enough Balance to Foreclose");
  }
}
);
    
  
}
//end of Function5() confirmation of foreclose
  function6(data)
  {
    this.validate2=data;
   
      alert("foreclose successfull")
      this.router.navigate(['/home/det'])
  }
}
