import { Component, OnInit } from '@angular/core';
import { Userservice1Service } from 'src/app/services/userservice1.service';
import { User } from 'src/app/models/user.model';

import { Transaction } from 'src/app/models/transaction.model';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {
  tran:Transaction[];
  validate:number;
  users:User;
  constructor(private userService:Userservice1Service) { }

  ngOnInit() {
    let u=sessionStorage.username
    this.userService.print(u).subscribe(data=>{
      this.tran=data;}
    ,
    err=>{
      console.log(err.stack);
    }
    )
    this.userService.getDetails(u).subscribe(data=>{
      this.users=data;}
    ,
    err=>{
      console.log(err.stack);
    }
    )
  }

}
