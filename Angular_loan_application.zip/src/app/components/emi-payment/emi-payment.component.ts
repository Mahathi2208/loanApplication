import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Userservice1Service } from 'src/app/services/userservice1.service';

@Component({
  selector: 'app-emi-payment',
  templateUrl: './emi-payment.component.html',
  styleUrls: ['./emi-payment.component.css']
})
export class EmiPaymentComponent implements OnInit {
    //creating formGroup object
emiForm:FormGroup;
validate1:number;
validate2:number;
// FormBuilder to build form elements with defaut values and validations
// Router service to navigate programmatically from component to other

  constructor(private formBuilder:FormBuilder,private router:Router,private userservice:Userservice1Service) { }

  ngOnInit() {
    
    this.emiForm=this.formBuilder.group({
     
      password: ['', Validators.required]
    });
  }
  //verify() function starts
  //function to verify password
  verify()
  {
    let u=sessionStorage.username;
      this.userservice.valid(u,this.emiForm.controls.password.value).subscribe(data=>{
        this.function5(data);
      },
      err=>{
        console.log(err.error);
        alert("Incorrect password");
      })

  }
  //end of verify() function

//function5() starts
//to process the emi payment
  function5(data)
  {
    let u=sessionStorage.username;
    this.validate1=data;
   
    
this.userservice.emiPayment(u).subscribe(data=>{
  this.function6(data);
},
err=>{
  console.log(err.error);
  
  //error when no pending loans are present
  if(err.error.message=="No pending Loans"){
    alert("No pending Loans")
  }
  //error when no enough balance is present
  if(err.error.message=="No enough balance to pay emi"){
    alert("No enough Balance to pay EMI")
  }
}
)
    
  
  }
  //end of function5()

  
  function6(data)
  {
    this.validate2=data;
  
      alert("emi payment successfull")
    this.router.navigate(['/home/det'])
    
  }
}
