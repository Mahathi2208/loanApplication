import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Userservice1Service } from 'src/app/services/userservice1.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  //creating formGroup object
depositForm:FormGroup;

// FormBuilder to build form elements with defaut values and validations
// Router service to navigate programmatically from component to other
constructor(private formBuilder:FormBuilder,private router:Router,private userservice:Userservice1Service) { }
validate:number;
  ngOnInit() {
    this.depositForm=this.formBuilder.group({
     //validations to amount
      amount:['',[Validators.required]]
    });
  }
  //verify() function to deposit amount
  verify()
  {
    
      let u=sessionStorage.username;
      this.userservice.depositAmt(u,this.depositForm.controls.amount.value).subscribe(data=>{
        this.function4(data);
      },
      err=>{
        console.log(err.stack);
      })
  }
 // end of verify() function

 //deposit confirmation function
  function4(data)
  {
   
  alert("deposit success")
  this.router.navigate(['/home/det'])
  }
}
