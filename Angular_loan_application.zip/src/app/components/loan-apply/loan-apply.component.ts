import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../../models/user.model';
import { Userservice1Service } from 'src/app/services/userservice1.service';

@Component({
  selector: 'app-loan-apply',
  templateUrl: './loan-apply.component.html',
  styleUrls: ['./loan-apply.component.css']
})
export class LoanApplyComponent implements OnInit {
   //creating formGroup object
  loginForm: FormGroup;
users:User;
  submitted: boolean= false;
  amt:number;
  validate:number;
  // FormBuilder to build form elements with defaut values and validations
// Router service to navigate programmatically from component to other
  constructor(private router:Router,private formBuilder:FormBuilder,private userService :Userservice1Service) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      
      firstName:['',[Validators.required,Validators.pattern("[A-Z][a-z]{2,14}")]],
      lastName:['',[Validators.required,Validators.pattern("[A-Z][a-z]{2,14}")]],
      age:['',[Validators.required,Validators.min(18),Validators.max(90)]],
      loanAmount:['',[Validators.required,Validators.min(200000)]],
      balance:['',[Validators.required,Validators.min(50000)]],
      pancard:['',[Validators.required,Validators.pattern("[A-Z]{5}[0-9]{4}[A-Z]{1}")]],
      phoneNumber:['',[Validators.required,Validators.pattern("[6-9][0-9]{9}")]],
      mailId:['',[Validators.required,Validators.email]],
      username:['',[Validators.required ,Validators.pattern("[A-Za-z]{4}[0-9]{4}")]],
      password: ['',[ Validators.required,Validators.pattern("[A-Za-z]{4}[0-9]{4}")]],
      assetValue:['',[Validators.required]],
      years:['',[Validators.required,Validators.max(15)]]
    });

  }
  
// register() function
register(){
  this.submitted = true;
  if(this.loginForm.invalid){
    return;

  }
  this.amt = this.userService.checkEmi(this.loginForm.controls.loanAmount.value,this.loginForm.controls.years.value)
  let result = confirm(`if loan approved your monthly emi will be ${this.amt}`);
    if(result){
  console.log(this.loginForm.value);
  this.userService.newAcc(this.loginForm.value).subscribe(data=>{
   
    this.function1(data);
},err=>{

  console.log(err.error)
  //error when username already exists
  if(err.error.message=="Username already exists"){
    alert("Username already exists");
  }
  //error when assetvalue is not greater than loan amount
  if(err.error.message=="Asset value must be greater than loan amount"){
    alert("Asset value must be greater than loan amount")
  }
});
}
}
// end of register() function
function1(data) {
 
  this.validate=data;
 
    
    alert("account created successfully login with your credentials")
    this.router.navigate(['/login']);
  
}
home()
{
  this.router.navigate(['/main']);
}
 

invalidLogin:boolean = false;
}
