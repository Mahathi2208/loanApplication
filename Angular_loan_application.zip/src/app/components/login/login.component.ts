import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Userservice1Service } from 'src/app/services/userservice1.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   //creating formGroup object
  loginForm: FormGroup;
  validate:number;
  submitted: boolean= false;
    // FormBuilder to build form elements with defaut values and validations
// Router service to navigate programmatically from component to other

  constructor(private formBuilder:FormBuilder,private router:Router,private userService:Userservice1Service) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username:['',Validators.required],
      password: ['', Validators.required]
    });
    if(sessionStorage.username!=null)
    {
      sessionStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }
// login() function
  login(){
    this.submitted = true;
    if(this.loginForm.invalid){
      return;
    }

    let username = this.loginForm.controls.username.value;
    let password = this.loginForm.controls.password.value;
this.userService.valid(username,password).subscribe(data=>{
  this.function2(data);
},
err=>{
  console.log(err.error);
  alert("Invalid login Credentials");
})   
  }
  // end of Login() function
  function2(data)
  {
    this.validate=data;
    
      let username = this.loginForm.controls.username.value;
      sessionStorage.username = username;
      this.router.navigate(['/home']);
    }
   
  home()
  {
    this.router.navigate(['/main']);
  }
      
  
 
  invalidLogin:boolean = false;
}
