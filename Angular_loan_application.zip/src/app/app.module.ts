import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { LoanApplyComponent } from './components/loan-apply/loan-apply.component';
import { EmiPaymentComponent } from './components/emi-payment/emi-payment.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BalanceComponent } from './components/balance/balance.component';
import { ForecloseComponent } from './components/foreclose/foreclose.component';
import { CalculateEmiComponent } from './components/calculate-emi/calculate-emi.component';
import { PrintTransactionComponent } from './components/print-transaction/print-transaction.component';
import { DepositComponent } from './components/deposit/deposit.component';
import { ContactComponent } from './components/contact/contact.component';
import { AboutComponent } from './components/about/about.component';
import { HelpComponent } from './components/help/help.component';
import { DetailsComponent } from './components/details/details.component';
import { MainHomeComponent } from './main-home/main-home.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    LoanApplyComponent,
    EmiPaymentComponent,
    BalanceComponent,
    ForecloseComponent,
    CalculateEmiComponent,
    PrintTransactionComponent,
    DepositComponent,
    ContactComponent,
    AboutComponent,
    HelpComponent,
    DetailsComponent,
    MainHomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule, // ReactiveFormsModule for Reactive forms,
    FormsModule, // FormsModule for Template driven forms
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
