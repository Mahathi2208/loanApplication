import { TestBed } from '@angular/core/testing';

import { Userservice1Service } from './userservice1.service';

describe('Userservice1Service', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Userservice1Service = TestBed.get(Userservice1Service);
    expect(service).toBeTruthy();
  });
});
