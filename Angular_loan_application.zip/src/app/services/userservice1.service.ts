import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';
import { Transaction } from '../models/transaction.model';

@Injectable({
  providedIn: 'root'
})
export class Userservice1Service {

  constructor(private http:HttpClient) { }
  baseUrl: string = "http://localhost:8081/api";

  newAcc(user:User)
  {
   
    return this.http.post(this.baseUrl+"/acc/add",user); 
  }
  valid(id:String,password:string)
  {
    return this.http.get(this.baseUrl+"/acc/pa"+"/"+id+"/"+password);  
  }
  getDetails(id:string)
  {
    return this.http.get<User>(this.baseUrl+"/acc"+"/"+id);
  }
  depositAmt(id:string,amt:number)
  {
    return this.http.get(this.baseUrl+"/acc/deposit"+"/"+id+"/"+amt);
  }
  forecloseAcc(id:string)
  {
    return this.http.get(this.baseUrl+"/acc/foreclose"+"/"+id);
  }
  emiPayment(id:string)
  {
    return this.http.get(this.baseUrl+"/acc/pay"+"/"+id);
  }
  checkEmi(amt:number,amt1:number):number
  {
  //   return this.http.get(this.baseUrl+"/acc/check"+"/"+amt+"/"+amt1);
  return Math.round(((amt/amt1)/12)*1.2);
   }
   print(id:string)
   {
     return this.http.get<Transaction[]>(this.baseUrl+"/acc/print"+"/"+id);
   }
}














