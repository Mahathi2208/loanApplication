export class User {
  //accountNo:number;
  firstName: string;
  lastName: string;
  age: number;
  loanAmount: number;
  balance: number;
  pancard: string;
  phoneNumber: string;
  mailId: string;
  username: string;
  password: string;
  assetValue: number;
  years: number;

}