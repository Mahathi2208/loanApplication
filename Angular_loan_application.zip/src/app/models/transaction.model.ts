export class Transaction{
primaryKey:number;
transactionId:number;
accountNumber:number;
transactionType:string;
currentBalance:number;
}