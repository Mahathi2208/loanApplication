import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { LoanApplyComponent } from './components/loan-apply/loan-apply.component';
import { EmiPaymentComponent } from './components/emi-payment/emi-payment.component';
import { CalculateEmiComponent } from './components/calculate-emi/calculate-emi.component';
import { BalanceComponent } from './components/balance/balance.component';
import { PrintTransactionComponent } from './components/print-transaction/print-transaction.component';
import { ForecloseComponent } from './components/foreclose/foreclose.component';
import { DepositComponent } from './components/deposit/deposit.component';
import { ContactComponent } from './components/contact/contact.component';
import { AboutComponent } from './components/about/about.component';
import { HelpComponent } from './components/help/help.component';
import { DetailsComponent } from './components/details/details.component';
import { MainHomeComponent } from './main-home/main-home.component';

// define routes for your components
// defining array of objects of Routes
const routes: Routes = [
   // Empty Route
  {path:'',component:MainHomeComponent},
  {path:'main',component:MainHomeComponent},
  {path:'home',component:HomeComponent, children:
[
  {path:'',component:DetailsComponent},
  {path:'det',component:DetailsComponent},
 
  {path:'emi',component:EmiPaymentComponent},
  {path:'calemi',component:CalculateEmiComponent},
  {path:'balance',component:BalanceComponent},
  {path:'print',component:PrintTransactionComponent},
  {path:'foreclose',component:ForecloseComponent},
  {path:'deposit',component:DepositComponent}
]},
  {path:'loan-apply',component:LoanApplyComponent},
  {path:'cont',component:ContactComponent},
  {path:'abt',component:AboutComponent},
  {path:'help',component:HelpComponent},
  {path:'login',component:LoginComponent},
   // Default Route
  // {path:'**',component:MainHomeComponent}
  {path:'**',component:MainHomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
